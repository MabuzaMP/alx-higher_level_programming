#!/usr/bin/python3
def add(a, b):
    """This will return the addition  of two numbers."""
    return (a + b)
