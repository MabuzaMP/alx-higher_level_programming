#!/usr/bin/python3
Square = __import__('11-square').Square

s = Square("erroR")

print(s)
print(s.area())
