#!/usr/bin/python3
Square = __import__('10-square').Square

s = Square("Error")

print(s)
print(s.area())
