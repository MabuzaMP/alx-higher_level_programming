const $ = window.$;
$('HEADER').css('color', '#FF0000');
