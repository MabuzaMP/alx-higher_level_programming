(function () {
  document.addEventListener('DOMContentLoaded', function () {
    document.querySelector('header').style.color = '#FF0000';
  }, false);
})();
