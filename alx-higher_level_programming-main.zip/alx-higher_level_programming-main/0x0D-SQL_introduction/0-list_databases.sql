-- Write a script that lists all databases of your MySQL server.
-- Lists all databases of my MySQL server
-- solution below

SHOW DATABASES;
