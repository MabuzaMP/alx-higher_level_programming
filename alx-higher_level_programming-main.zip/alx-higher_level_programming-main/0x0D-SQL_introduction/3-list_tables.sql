-- Lists all the tables of my database in my MySQL server
-- Write a script that lists all the tables of a database in your MySQL server.

-- The database name will be passed as argument of mysql command (in the following example: mysql is the name of the database)

SHOW TABLES;
