require('../100-let_me_const')
myVar = 89
console.log(myVar)
