#!/usr/bin/node
const s = ['C is fun', 'Python is cool', 'JavaScript is amazing']
for (let i = 0; i < s.length; i++) {
  console.log(s[i])
}
