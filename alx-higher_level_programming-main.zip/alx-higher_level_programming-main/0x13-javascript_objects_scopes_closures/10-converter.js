#!/usr/bin/node
exports.converter = function (base) {
  return (num) => num.toString(base)
}
